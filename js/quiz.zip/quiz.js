let currentQuestion = 1;

function showQuestion(questionId) {
    const currentQuestionElement = document.getElementById(`question${currentQuestion}`);
    const nextQuestionElement = document.getElementById(questionId);

    currentQuestionElement.style.display = 'none';
    nextQuestionElement.style.display = 'block';

    if (questionId === 'question1') {
        currentQuestion = 1;
    } else if (questionId === 'question2') {
        currentQuestion = 2;
    } else if (questionId === 'question3') {
        currentQuestion = 3;
    } else if (questionId === 'question4') {
        currentQuestion = 4;
    } else if (questionId === 'question5') {
        currentQuestion = 5;
    }

}

function sendFormData() {
    const countryCode2 = document.getElementById('countryCode').value;
    const consent = document.getElementById('consentCheckbox').checked;

    if (!consent) {
        alert('Пожалуйста, дайте согласие на обработку персональных данных.');
        return;
    }
    if (!countryCode2) {
        countryCode.setAttribute("class", "validat")
        return;
    }
    $('#exampleModal').modal('show');

    const formData = new FormData();
    formData.append('countryCode2', countryCode2);

    fetch('/submit_form', {
        method: 'POST',
        body: formData
    })
        .then(response => response.text())
        .then(data => {
            console.log(data);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}



